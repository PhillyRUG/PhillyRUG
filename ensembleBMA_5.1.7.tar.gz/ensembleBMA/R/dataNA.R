dataNA <-
function(ensembleData, forecasts = TRUE, observations = TRUE, dates = TRUE) {
#
# copyright 2006-present, University of Washington. All rights reserved.
# for terms of use, see the LICENSE file
#
UseMethod("dataNA")
}

