modelMembers <-
function( BMAobject) {
#
# copyright 2006-present, University of Washington. All rights reserved.
# for terms of use, see the LICENSE file
#
UseMethod("modelMembers")
}
