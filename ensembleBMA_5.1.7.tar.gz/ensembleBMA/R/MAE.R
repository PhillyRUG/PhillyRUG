`MAE` <-
function(fit, ensembleData, dates=NULL, ...) 
UseMethod("MAE")

