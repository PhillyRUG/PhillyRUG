crps <-
function(fit, ensembleData, dates=NULL, nSamples=NULL, seed=NULL, ...) {
#
# copyright 2006-present, University of Washington. All rights reserved.
# for terms of use, see the LICENSE file
#
UseMethod("crps")
}

